# v1 Error Codes

## Update warnings

`UPDATE_CHECK_UNAVAILABLE` and `UPDATE_APPLY_UNAVAILABLE` are bounded warnings:
the last validated local installation remains usable. Candidate identity, path,
manifest, wheel, malformed JSON, same-version, and downgrade failures are never
authorization to replace the local installation.

`UPDATE_TRANSACTION_FAILED` is an `ok: false` receipt with a bounded `stage`
(`launcher` or `project`), `rolled_back`, and `project_updated: false`. It
means a validated forward candidate could not complete a local installation
stage; normal startup stops rather than running with mixed bytes.

| Code | Meaning | Write guarantee |
|---|---|---|
| `PROJECT_NOT_FOUND` | No explicit or discovered project config | No write |
| `PROJECT_PATH_ESCAPE` | Configured path or symlink leaves project root | No write |
| `PROJECT_ID_MISMATCH` | Input/state project differs from resolved project | No write |
| `CONFIG_SCHEMA_UNSUPPORTED` | Config version is not supported | No write |
| `STATE_SCHEMA_UNSUPPORTED` | State version is unknown or higher | No write |
| `INPUT_SCHEMA_INVALID` | Envelope, type, reserved, or unknown field invalid | No write |
| `PUBLISH_OPERATION_INVALID` | Missing/unknown `operation`, or operation does not match item shape | No write |
| `PUBLISH_OPERATION_MISMATCH` | CLI mode and envelope operation disagree: no `--update` requires `create`; `--update` requires `update` | No write |
| `TASK_ID_DUPLICATE` | Duplicate within batch or existing state on create | No write |
| `DEPENDENCY_INVALID` | Missing, self, or cyclic dependency | No write |
| `TASK_UPDATE_FORBIDDEN` | Update targets an ineligible state or reserved field | No write |
| `LOCK_TIMEOUT` | State lock was not acquired before timeout | No write |
| `MIGRATION_INVALID` | Target migration cannot be fully validated | Original bytes unchanged |
| `OBSERVATION_LOG_WARNING` | State committed but optional JSONL append failed | `ok: true`; state remains authoritative |

Machine-readable failures contain `ok: false`, `error.code`, `error.message`, and `project` when resolution succeeded. CLI/envelope operation agreement is checked before task validation and lock acquisition. For example, `publish --update` with `operation: "create"`, or publish without `--update` with `operation: "update"`, returns `PUBLISH_OPERATION_MISMATCH` and changes no bytes. Batch validation is performed before opening the commit path. A successful publish with an observation-log failure contains `ok: true` and `warnings: [{"code":"OBSERVATION_LOG_WARNING","message":"state committed; observation log append failed","rebuild_from":"publish_history"}]`.

Lifecycle authorization failures use stable `reason` values. The 0.2.0 security
set includes `unknown_worker`, `staff_cannot_execute_tasks`,
`required_worker_mismatch`, `agent_type_not_allowed`, `task_kind_not_allowed`,
`required_metadata_missing`, `worker_already_leased`, `writable_path_locked`,
`stale_lease`, `lease_expired`, and `summary_required`. These failures do not
commit the rejected transition. Whitespace-only strings and empty collections
are treated as missing; scheduler validation does not independently prove that
human authorization text is truthful.
