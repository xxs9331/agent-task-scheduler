"""Core scheduler orchestration."""
