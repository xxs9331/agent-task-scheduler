"""Lifecycle state transitions."""
